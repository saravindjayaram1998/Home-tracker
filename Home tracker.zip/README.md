# Home Tracker — setup guide

A shared chore tracker for Shikha & Aravind. One web link that works on any phone, laptop, Chrome, Edge. Every tick is saved to a shared cloud database, so all devices stay in sync.

You only do this setup once. Takes about 10–15 minutes. Everything below is free, no credit card.

---

## What you need
- A GitHub account (you have one)
- A Vercel account (free) — sign in with GitHub
- An Upstash Redis database (free) — added inside Vercel with a few clicks

---

## Step 1 — Put this code on GitHub
1. Go to https://github.com/new and create a new repository. Name it anything, e.g. `home-tracker`. Keep it Private if you like. Click **Create repository**.
2. On the new repo page, click **uploading an existing file**.
3. Drag in ALL the files from this folder, keeping the structure:
   - `index.html`
   - `package.json`
   - `.gitignore`
   - the `api` folder (with `data.js` inside it)
4. Click **Commit changes**.

> Tip: drag the `api` folder in as-is so `api/data.js` stays inside it. If GitHub flattens it, create the file manually: **Add file → Create new file**, name it `api/data.js`, paste the contents.

---

## Step 2 — Deploy on Vercel
1. Go to https://vercel.com and **Sign up / Log in with GitHub**.
2. Click **Add New… → Project**.
3. Find your `home-tracker` repo and click **Import**.
4. Leave every setting at default (Framework Preset: **Other** is fine). Click **Deploy**.
5. Wait for it to finish. It will give you a URL like `home-tracker-xxxx.vercel.app`.

At this point the page loads but it can't save yet — we add the database next.

---

## Step 3 — Add the shared database (Upstash Redis)
1. In your Vercel project, open the **Storage** tab.
2. Click **Create Database** → choose **Upstash → Redis** (in the Marketplace). Accept / install if asked.
3. When prompted, let Vercel create an Upstash account/database for you, pick the free plan, and **connect it to this project**.
4. Vercel automatically adds two environment variables to your project: `KV_REST_API_URL` and `KV_REST_API_TOKEN`. You don't type anything — it's automatic.

---

## Step 4 — Redeploy so it picks up the database
1. Go to the **Deployments** tab in your Vercel project.
2. On the most recent deployment, click the **…** menu → **Redeploy** → confirm.
3. When it finishes, open your `.vercel.app` URL.

Done. Tick a task on your phone, open the same link on your laptop, hit **Refresh now** (or wait ~4 seconds) — it shows up. That's the shared sync working.

---

## Using it
- **Pick who you are**: tap **Shikha** or **Aravind** under "You are" once on each device. Your approvals get attributed to you. (Stored on that device only.)
- **Day view**: tap any tile to mark done. Tasks appear on the right days automatically (daily, Sunday-only, Mon/Wed/Fri, monthly bills on the 1st).
- **Month view**: each day is colored — red under 50% done, yellow 50–80%, green over 80%.
- **Everyone / Shikha / Aravind** filter at the top.
- **Add / edit tasks**: button at the top. Propose a task with owner, time, category, repeat. Remove any task with the × .

## Approving new tasks
- A proposed task is **pending** and does NOT show in day/month yet.
- The person who proposed it auto-approves. The other person sees it under the **bell icon (Notifications)** with a count badge.
- Once **both** approve, the task goes live and starts appearing on the right days.
- Each pending task shows an approval tracker: Shikha ✓ / Aravind ⏳.

## Share the link
Just send each other the `.vercel.app` URL and bookmark it / add to home screen. No login. (Heads up: anyone with the link can view and tick. It's an open link, as you chose.)

## Want it private later?
Tell Claude "add a passcode" and it'll add a simple shared password gate.
